import { t } from '../../localization/Localization.ts';
import type { Language } from '../../settings/Preferences.ts';
import { ENGLISH } from '../../localization/English.ts';
import type { MasteryRank, MasteryStageProgress, MetaSave } from '../../meta/MetaSave.ts';
import { getMasteryRequirements } from '../../meta/mastery/Mastery.ts';

export interface VictoryMasteryMetric {
  readonly key: keyof MasteryStageProgress;
  readonly current: number;
  readonly total: number;
}

export interface VictoryMasterySnapshot {
  readonly rank: MasteryRank;
  readonly metrics: readonly VictoryMasteryMetric[];
}

export interface VictoryMasteryState {
  readonly before: VictoryMasterySnapshot;
  readonly after: VictoryMasterySnapshot;
  readonly rankAdvancedTo: MasteryRank | null;
  readonly rankRewardCoins: number;
}

export interface WinOverlayMasteryContent {
  readonly beforeRank: MasteryRank;
  readonly afterRank: MasteryRank;
  readonly beforeRankLabel: string;
  readonly afterRankLabel: string;
  readonly beforeProgressCurrent: number;
  readonly beforeProgressTotal: number;
  readonly afterProgressCurrent: number;
  readonly afterProgressTotal: number;
  readonly beforeCaption: string;
  readonly afterCaption: string;
  readonly promoted: boolean;
  readonly rewardLine: string | null;
}

const METRIC_KEYS: readonly (keyof MasteryStageProgress)[] = ['anyWins', 'mediumWins', 'hardWins', 'onTimeDailyWins'];
const RANK_LABELS: Readonly<Record<MasteryRank, string>> = {
  novice: 'Новичок',
  player: 'Игрок',
  tactician: 'Тактик',
  expert: 'Эксперт',
  master: 'Мастер',
  grandmaster: 'Грандмастер',
};
const METRIC_LABELS: Readonly<Record<keyof MasteryStageProgress, string>> = {
  anyWins: 'Победы',
  mediumWins: 'Средняя',
  hardWins: 'Сложная',
  onTimeDailyWins: 'Daily вовремя',
};

function tr(language: Language, source: string): string {
  return language === 'en' ? ENGLISH[source] ?? source : source;
}

function snapshotFromState(state: MetaSave): VictoryMasterySnapshot {
  const requirements = getMasteryRequirements(state.mastery.rank);
  const metrics = requirements
    ? METRIC_KEYS
      .filter((key) => requirements[key] > 0)
      .map((key) => ({ key, current: state.mastery.stage[key], total: requirements[key] }))
    : [];
  return { rank: state.mastery.rank, metrics };
}

function metricsChanged(before: readonly VictoryMasteryMetric[], after: readonly VictoryMasteryMetric[]): boolean {
  if (before.length !== after.length) return true;
  for (let index = 0; index < before.length; index += 1) {
    const left = before[index];
    const right = after[index];
    if (!left || !right) return true;
    if (left.key !== right.key || left.current !== right.current || left.total !== right.total) return true;
  }
  return false;
}

function aggregateProgress(metrics: readonly VictoryMasteryMetric[]): { current: number; total: number } {
  if (metrics.length === 0) return { current: 1, total: 1 };
  if (metrics.length === 1) return { current: metrics[0]!.current, total: metrics[0]!.total };
  const total = metrics.length;
  const current = metrics.reduce((sum, metric) => sum + Math.min(metric.current / Math.max(1, metric.total), 1), 0);
  return { current, total };
}

function formatCaption(metrics: readonly VictoryMasteryMetric[], language: Language): string {
  if (metrics.length === 0) return tr(language, 'Все ранги открыты');
  return metrics
    .map((metric) => `${tr(language, METRIC_LABELS[metric.key])}: ${metric.current} / ${metric.total}`)
    .join(' · ');
}

export function buildVictoryMasteryState(before: MetaSave, after: MetaSave, rankAdvancedTo: MasteryRank | null): VictoryMasteryState | null {
  const previous = snapshotFromState(before);
  const next = snapshotFromState(after);
  if (rankAdvancedTo === null && previous.rank === next.rank && !metricsChanged(previous.metrics, next.metrics)) return null;
  return {
    before: previous,
    after: next,
    rankAdvancedTo,
    rankRewardCoins: rankAdvancedTo ? (getMasteryRequirements(previous.rank)?.rewardCoins ?? 0) : 0,
  };
}

export function presentVictoryMastery(content: VictoryMasteryState, language: Language = 'ru'): WinOverlayMasteryContent {
  const beforeProgress = aggregateProgress(content.before.metrics);
  const afterProgress = aggregateProgress(content.after.metrics);
  return {
    beforeRank: content.before.rank,
    afterRank: content.after.rank,
    beforeRankLabel: tr(language, RANK_LABELS[content.before.rank]),
    afterRankLabel: tr(language, RANK_LABELS[content.after.rank]),
    beforeProgressCurrent: beforeProgress.current,
    beforeProgressTotal: beforeProgress.total,
    afterProgressCurrent: afterProgress.current,
    afterProgressTotal: afterProgress.total,
    beforeCaption: formatCaption(content.before.metrics, language),
    afterCaption: formatCaption(content.after.metrics, language),
    promoted: content.rankAdvancedTo !== null,
    rewardLine: content.rankRewardCoins > 0
      ? t('Награда за ранг: +{count} монет', { count: content.rankRewardCoins })
      : null,
  };
}
