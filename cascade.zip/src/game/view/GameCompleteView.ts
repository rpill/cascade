import type * as Phaser from 'phaser';
import { t } from '../../localization/Localization.ts';
import type { SfxCue } from '../../settings/SfxController.ts';
import type { MasteryRank } from '../../meta/MetaSave.ts';
import type { ViewportLayout } from './ViewportLayout.ts';
import { WinOverlay, type WinOverlayContent } from '../../ui/win/WinOverlay.ts';
import type { RewardSummaryState } from './RewardSummaryView.ts';
import { presentVictoryMastery, type VictoryMasteryState } from './VictoryMastery.ts';
import { getLanguage } from '../../localization/Localization.ts';

export interface GameCompleteState {
  readonly completionId: string;
  readonly mode: 'original' | 'winnable';
  readonly elapsedMs: number;
  readonly improvedBest: boolean;
  readonly reward?: RewardSummaryState;
  readonly rewardActionLabel?: string | null;
  readonly rewardActionEnabled?: boolean;
  readonly rewardDoubled?: boolean;
  readonly mastery?: VictoryMasteryState | null;
}

export interface GameCompleteActions {
  readonly newGame: () => void;
  readonly menu: () => void;
  readonly doubleCoins?: () => void;
  readonly sound?: (cue: SfxCue) => void;
}

const RANK_LABELS: Readonly<Record<MasteryRank,string>> = {
  novice:'Новичок', player:'Игрок', tactician:'Тактик', expert:'Эксперт', master:'Мастер', grandmaster:'Грандмастер',
};

function formatDuration(ms:number):string {
  const totalSeconds=Math.floor(Math.max(0,ms)/1000);
  return `${Math.floor(totalSeconds/60)}:${String(totalSeconds%60).padStart(2,'0')}`;
}

function rewardLine(reward:RewardSummaryState|undefined):string|null {
  if (!reward) return null;
  if (reward.pending) return t('Награды начисляются…');
  return reward.coins > 0 ? `+${reward.coins}` : t('Без повторной награды');
}

function rewardCoins(reward:RewardSummaryState|undefined):number|null {
  if (!reward || reward.pending || reward.coins <= 0) return null;
  return reward.coins;
}

function detailLine(reward:RewardSummaryState|undefined):string|null {
  if (!reward || reward.pending || !reward.rankAdvancedTo) return null;
  return t('Новый ранг: {rank}', {rank:t(RANK_LABELS[reward.rankAdvancedTo])});
}

function contentFor(state:GameCompleteState):WinOverlayContent {
  const noticeParts = [
    state.rewardDoubled ? t('Награда удвоена') : null,
    state.reward?.themePurchaseUnlocked ? t('Доступны новые темы в коллекции') : null,
  ].filter((value): value is string => Boolean(value));
  return {
    title:t('ПОБЕДА'),
    kicker:state.mode==='winnable'?t('ИГРА'):t('КЛАССИКА'),
    resultLine:state.improvedBest
      ? `${t('Время: {value0}', { value0: formatDuration(state.elapsedMs) })} · ${t('Новый рекорд')}`
      : t('Время: {value0}', { value0: formatDuration(state.elapsedMs) }),
    rewardLine:rewardLine(state.reward),
    rewardCoins: rewardCoins(state.reward),
    detailLine:detailLine(state.reward),
    noticeLine:noticeParts.length > 0 ? noticeParts.join(' · ') : null,
    primaryActionLabel:t('НОВАЯ РАЗДАЧА'),
    secondaryActionLabel:t('В МЕНЮ'),
    rewardActionLabel:state.rewardActionLabel ?? null,
    rewardActionEnabled:state.rewardActionEnabled === true,
    mastery: state.mastery ? presentVictoryMastery(state.mastery, getLanguage()) : null,
  };
}

/** Trifold-style Phaser victory overlay adapted to Cascade's existing completion contract. */
export class GameCompleteView {
  private readonly overlay:WinOverlay;
  private state:GameCompleteState|null=null;
  private layoutState:ViewportLayout|null=null;
  private lastCelebratedCompletionId:string|null=null;

  constructor(scene:Phaser.Scene, private readonly actions:GameCompleteActions) {
    const initial:GameCompleteState={completionId:'',mode:'winnable',elapsedMs:0,improvedBest:false};
    this.overlay=new WinOverlay(scene,contentFor(initial),{newDeal:actions.newGame,home:actions.menu,doubleCoins:actions.doubleCoins},5000);
    this.overlay.setVisible(false);
  }

  refreshLocalization():void {
    if (this.state) this.overlay.setContent(contentFor(this.state));
  }

  show(state:GameCompleteState):void {
    this.state=state;
    this.overlay.setContent(contentFor(state));
    this.overlay.setVisible(true);
    if (this.layoutState) this.overlay.layout(this.layoutState);
    const freshCompletion = state.completionId!==this.lastCelebratedCompletionId;
    if (freshCompletion) {
      this.lastCelebratedCompletionId=state.completionId;
      this.actions.sound?.('victory');
      if (state.reward && !state.reward.pending && state.reward.coins>0) this.actions.sound?.('coin-reward');
    }
    if (freshCompletion) this.overlay.playMasteryAnimation();
  }

  layout(layout:ViewportLayout):void { this.layoutState=layout; this.overlay.layout(layout); }
  hide():void { this.overlay.setVisible(false); }
  destroy():void { this.overlay.destroy(); }
}
