import * as Phaser from 'phaser';
import type { ViewportLayout } from '../../game/view/ViewportLayout.ts';
import { PaperPanel } from '../components/PaperPanel.ts';
import { UI_TOKENS } from '../style/UiTokens.ts';
import { UiSurface } from '../components/UiSurface.ts';
import { playUiButtonSound } from '../sound/UiSound.ts';
import { ProgressMeter } from '../components/ProgressMeter.ts';
import { CASCADE_UI_ART_KEYS } from '../assets/CascadeUiArt.ts';
import { UI_ICON_KEYS } from '../assets/UiAssets.ts';

export interface WinOverlayMasteryContent {
  readonly beforeRank: keyof typeof CASCADE_UI_ART_KEYS.rank;
  readonly afterRank: keyof typeof CASCADE_UI_ART_KEYS.rank;
  readonly beforeRankLabel: string;
  readonly afterRankLabel: string;
  readonly beforeProgressCurrent: number;
  readonly beforeProgressTotal: number;
  readonly afterProgressCurrent: number;
  readonly afterProgressTotal: number;
  readonly beforeCaption: string;
  readonly afterCaption: string;
  readonly promoted: boolean;
  readonly rewardLine: string | null;
}

export interface WinOverlayContent {
  readonly title: string;
  readonly kicker: string | null;
  readonly resultLine: string;
  readonly rewardLine: string | null;
  readonly rewardCoins: number | null;
  readonly detailLine: string | null;
  readonly noticeLine: string | null;
  readonly primaryActionLabel: string;
  readonly secondaryActionLabel: string;
  readonly rewardActionLabel: string | null;
  readonly rewardActionEnabled: boolean;
  readonly mastery?: WinOverlayMasteryContent | null;
}

export interface WinOverlayActions {
  readonly newDeal: () => void;
  readonly home: () => void;
  readonly doubleCoins?: () => void;
}

interface OverlayButton {
  readonly surface: UiSurface;
  readonly label: Phaser.GameObjects.Text;
  readonly zone: Phaser.GameObjects.Zone;
  readonly action: () => void;
  enabled: boolean;
}

export class WinOverlay {
  private readonly dimmer: Phaser.GameObjects.Rectangle;
  private readonly panel: PaperPanel;
  private readonly title: Phaser.GameObjects.Text;
  private readonly kicker: Phaser.GameObjects.Text;
  private readonly result: Phaser.GameObjects.Text;
  private readonly rewardIcon: Phaser.GameObjects.Image;
  private readonly reward: Phaser.GameObjects.Text;
  private readonly detail: Phaser.GameObjects.Text;
  private readonly notice: Phaser.GameObjects.Text;
  private readonly masteryBadge: Phaser.GameObjects.Image;
  private readonly masteryRank: Phaser.GameObjects.Text;
  private readonly masteryCaption: Phaser.GameObjects.Text;
  private readonly masteryReward: Phaser.GameObjects.Text;
  private readonly masteryMeter: ProgressMeter;
  private readonly primary: OverlayButton;
  private readonly secondary: OverlayButton;
  private readonly rewardAction: OverlayButton;
  private content: WinOverlayContent;
  private readonly actions: WinOverlayActions;
  private visible = true;
  private lastLayout: ViewportLayout | null = null;
  private masteryMeterBounds: { x: number; y: number; width: number; height: number } | null = null;

  constructor(
    scene: Phaser.Scene,
    content: WinOverlayContent,
    actions: WinOverlayActions,
    depth = 5000,
  ) {
    this.content = content;
    this.actions = actions;
    this.dimmer = scene.add.rectangle(0, 0, 1, 1, UI_TOKENS.color.overlay, 0.74)
      .setOrigin(0)
      .setDepth(depth)
      .setInteractive();
    this.panel = new PaperPanel(scene, { textureKey: UI_TOKENS.asset.paperPanel, depth: depth + 1 });
    this.kicker = scene.add.text(0, 0, '', {
      color: '#7a642f', fontFamily: 'system-ui, sans-serif', fontStyle: 'bold', align: 'center',
    }).setOrigin(0.5).setDepth(depth + 2);
    this.title = scene.add.text(0, 0, '', {
      color: '#24302e', fontFamily: 'Georgia, serif', fontStyle: 'bold', align: 'center',
    }).setOrigin(0.5).setDepth(depth + 2);
    this.result = scene.add.text(0, 0, '', {
      color: '#24302e', fontFamily: 'system-ui, sans-serif', fontStyle: 'bold', align: 'center',
    }).setOrigin(0.5).setDepth(depth + 2);
    this.rewardIcon = scene.add.image(0, 0, UI_ICON_KEYS.coin).setOrigin(0.5).setTint(UI_TOKENS.color.goldLight).setDepth(depth + 2);
    this.reward = scene.add.text(0, 0, '', {
      color: '#7a642f', fontFamily: 'system-ui, sans-serif', fontStyle: 'bold', align: 'left',
    }).setOrigin(0, 0.5).setDepth(depth + 2);
    this.detail = scene.add.text(0, 0, '', {
      color: '#64706a', fontFamily: 'system-ui, sans-serif', align: 'center',
    }).setOrigin(0.5).setDepth(depth + 2);
    this.notice = scene.add.text(0, 0, '', {
      color: '#8b7430', fontFamily: 'system-ui, sans-serif', fontStyle: 'bold', align: 'center',
    }).setOrigin(0.5).setDepth(depth + 2);
    this.masteryBadge = scene.add.image(0, 0, CASCADE_UI_ART_KEYS.rank.novice).setDepth(depth + 2);
    this.masteryRank = scene.add.text(0, 0, '', {
      color: '#24302e', fontFamily: 'Georgia, serif', fontStyle: 'bold', align: 'left',
    }).setOrigin(0, 0).setDepth(depth + 2);
    this.masteryCaption = scene.add.text(0, 0, '', {
      color: '#64706a', fontFamily: 'system-ui, sans-serif', align: 'left',
    }).setOrigin(0, 0).setDepth(depth + 2);
    this.masteryReward = scene.add.text(0, 0, '', {
      color: '#7a642f', fontFamily: 'system-ui, sans-serif', fontStyle: 'bold', align: 'left',
    }).setOrigin(0, 0).setDepth(depth + 2);
    this.masteryMeter = new ProgressMeter(scene, depth + 2);
    this.primary = this.createButton(scene, actions.newDeal, depth + 2);
    this.secondary = this.createButton(scene, actions.home, depth + 2);
    this.rewardAction = this.createButton(scene, () => this.actions.doubleCoins?.(), depth + 2);
    this.syncContent();
  }

  setContent(content: WinOverlayContent): void {
    this.content = content;
    this.syncContent();
  }

  playMasteryAnimation(): void {
    const mastery = this.content.mastery;
    if (!this.visible || !mastery) return;
    const scene = this.dimmer.scene;
    scene.tweens.killTweensOf(this.masteryBadge);
    scene.tweens.killTweensOf(this.masteryRank);
    scene.tweens.killTweensOf(this.masteryCaption);
    scene.tweens.killTweensOf(this.masteryReward);
    this.masteryBadge.setAlpha(1).setTexture(CASCADE_UI_ART_KEYS.rank[mastery.beforeRank]);
    this.masteryRank.setAlpha(1).setText(mastery.beforeRankLabel);
    this.masteryCaption.setAlpha(1).setText(mastery.beforeCaption);
    this.masteryReward.setAlpha(mastery.promoted && mastery.rewardLine ? 0 : 1).setText(mastery.promoted ? '' : (mastery.rewardLine ?? ''));
    this.masteryMeter.setProgress({ current: mastery.beforeProgressCurrent, total: mastery.beforeProgressTotal });
    if (this.masteryMeterBounds) this.masteryMeter.layout(this.masteryMeterBounds);

    if (mastery.promoted) {
      const gauge = { value: mastery.beforeProgressCurrent };
      scene.tweens.add({
        targets: gauge,
        value: mastery.beforeProgressTotal,
        duration: 700,
        ease: 'Cubic.Out',
        onUpdate: () => {
          this.masteryMeter.setProgress({ current: gauge.value, total: mastery.beforeProgressTotal });
          if (this.masteryMeterBounds) this.masteryMeter.layout(this.masteryMeterBounds);
        },
        onComplete: () => {
          scene.tweens.add({
            targets: [this.masteryBadge, this.masteryRank, this.masteryCaption],
            alpha: 0,
            duration: 180,
            ease: 'Sine.In',
            onComplete: () => {
              this.masteryBadge.setTexture(CASCADE_UI_ART_KEYS.rank[mastery.afterRank]);
              this.masteryRank.setText(mastery.afterRankLabel);
              this.masteryCaption.setText(mastery.afterCaption);
              this.masteryReward.setText(mastery.rewardLine ?? '');
              this.masteryMeter.setProgress({ current: mastery.afterProgressCurrent, total: mastery.afterProgressTotal });
              if (this.masteryMeterBounds) this.masteryMeter.layout(this.masteryMeterBounds);
              scene.tweens.add({
                targets: [this.masteryBadge, this.masteryRank, this.masteryCaption, this.masteryReward],
                alpha: 1,
                duration: 260,
                ease: 'Sine.Out',
              });
            },
          });
        },
      });
      return;
    }

    if (mastery.beforeProgressCurrent === mastery.afterProgressCurrent && mastery.beforeProgressTotal === mastery.afterProgressTotal) return;
    const gauge = { value: mastery.beforeProgressCurrent };
    scene.tweens.add({
      targets: gauge,
      value: mastery.afterProgressCurrent,
      duration: 700,
      ease: 'Cubic.Out',
      onUpdate: () => {
        this.masteryMeter.setProgress({ current: gauge.value, total: mastery.afterProgressTotal });
        if (this.masteryMeterBounds) this.masteryMeter.layout(this.masteryMeterBounds);
      },
      onComplete: () => {
        this.masteryCaption.setText(mastery.afterCaption);
      },
    });
  }

  setVisible(visible: boolean): void {
    this.visible = visible;
    this.dimmer.setVisible(visible).setActive(visible);
    if (visible) this.dimmer.setInteractive(); else this.dimmer.disableInteractive();
    this.panel.setVisible(visible);
    for (const text of [this.kicker, this.title, this.result, this.reward, this.detail, this.notice, this.masteryRank, this.masteryCaption, this.masteryReward]) text.setVisible(visible);
    this.rewardIcon.setVisible(visible && this.content.rewardCoins !== null);
    this.masteryBadge.setVisible(visible);
    this.masteryMeter.setVisible(visible);
    for (const button of [this.primary, this.secondary, this.rewardAction]) {
      button.surface.setVisible(visible);
      button.label.setVisible(visible);
      button.zone.setVisible(visible).setActive(visible);
      if (!visible) button.zone.disableInteractive();
    }
    if (visible) this.syncContent();
  }

  layout(layout: ViewportLayout): void {
    if (!this.visible) return;
    this.lastLayout = layout;
    const compact = layout.profile === 'compact-landscape';
    const margin = Math.max(12, layout.hudBounds.height * 0.35);
    const maxWidth = compact ? layout.viewportWidth * 0.74 : layout.viewportWidth * 0.5;
    const width = Math.min(maxWidth, Math.max(layout.cardWidth * (compact ? 5.8 : 5.4), compact ? 440 : 600));
    const maxHeight = layout.viewportHeight - margin * 2;
    const height = Math.min(maxHeight, compact ? layout.viewportHeight * 0.86 : layout.viewportHeight * 0.62);
    const x = (layout.viewportWidth - width) / 2;
    const y = (layout.viewportHeight - height) / 2;
    const buttonHeight = Math.max(layout.hudBounds.height, compact ? 44 : 48);
    const gap = compact ? 8 : 14;
    const innerX = x + width * 0.09;
    const innerWidth = width * 0.82;
    const hasMastery = Boolean(this.content.mastery);

    this.dimmer.setPosition(0, 0).setSize(layout.viewportWidth, layout.viewportHeight);
    this.panel.layout({ x, y, width, height });

    const kickerY = y + height * 0.10;
    const titleY = y + height * 0.21;
    const resultY = y + height * (hasMastery ? 0.34 : 0.39);
    const rewardY = y + height * (hasMastery ? 0.43 : 0.52);
    const detailY = y + height * (hasMastery ? 0.77 : 0.62);
    const noticeY = y + height * (hasMastery ? 0.84 : 0.70);
    this.kicker.setPosition(x + width / 2, kickerY).setFontSize(Math.max(11, Math.min(18, height * 0.045)));
    this.title.setPosition(x + width / 2, titleY)
      .setFontSize(Math.max(18, Math.min(36, height * 0.085)))
      .setWordWrapWidth(width * 0.82, true)
      .setLineSpacing(-2);
    this.result.setPosition(x + width / 2, resultY).setFontSize(Math.max(13, Math.min(22, height * 0.05))).setWordWrapWidth(width * 0.82, true);
    this.reward.setFontSize(Math.max(13, Math.min(24, height * 0.052)));
    if (this.content.rewardLine) {
      if (this.content.rewardCoins !== null) {
        const iconSize = Math.max(16, Math.min(22, height * 0.042));
        const rewardGap = Math.max(8, iconSize * 0.35);
        const totalWidth = iconSize + rewardGap + this.reward.width;
        const left = x + width / 2 - totalWidth / 2;
        this.rewardIcon.setDisplaySize(iconSize, iconSize).setPosition(left + iconSize / 2, rewardY).setVisible(true);
        this.reward.setPosition(left + iconSize + rewardGap, rewardY).setVisible(true);
      } else {
        this.rewardIcon.setVisible(false);
        this.reward.setPosition(x + width / 2 - this.reward.width / 2, rewardY).setVisible(true);
      }
    } else {
      this.rewardIcon.setVisible(false);
    }
    this.detail.setPosition(x + width / 2, detailY).setFontSize(Math.max(11, Math.min(18, height * 0.04))).setWordWrapWidth(width * 0.78, true);
    this.notice.setPosition(x + width / 2, noticeY).setFontSize(Math.max(10, Math.min(16, height * 0.033))).setWordWrapWidth(width * 0.78, true);

    if (hasMastery && this.content.mastery) {
      const badgeSize = Math.min(compact ? 74 : 94, height * 0.19);
      const badgeX = x + width * 0.20;
      const badgeY = y + height * 0.61;
      const meterWidth = innerWidth * 0.44;
      const textX = badgeX + badgeSize * 0.72;
      const textTop = badgeY - badgeSize * 0.50;
      const rankFont = Math.max(18, Math.min(30, height * 0.055));
      const captionFont = Math.max(11, Math.min(17, height * 0.034));
      const rewardFont = Math.max(10, Math.min(15, height * 0.030));
      const textGap = Math.max(6, height * 0.012);
      this.masteryBadge.setPosition(badgeX, badgeY).setDisplaySize(badgeSize, badgeSize).setVisible(true);
      this.masteryRank.setPosition(textX, textTop).setFontSize(rankFont).setVisible(true);
      this.masteryCaption.setPosition(textX, textTop + rankFont + textGap).setFontSize(captionFont).setWordWrapWidth(meterWidth, true).setVisible(true);
      const captionHeight = this.masteryCaption.height;
      const rewardY2 = textTop + rankFont + textGap + captionHeight + textGap;
      this.masteryReward.setPosition(textX, rewardY2).setFontSize(rewardFont).setWordWrapWidth(meterWidth, true).setVisible(Boolean(this.masteryReward.text));
      const rewardHeight = this.masteryReward.visible ? this.masteryReward.height : 0;
      this.masteryMeterBounds = { x: textX, y: rewardY2 + rewardHeight + textGap, width: meterWidth, height: Math.max(7, height * 0.014) };
      this.masteryMeter.layout(this.masteryMeterBounds);
    } else {
      this.masteryBadge.setVisible(false);
      this.masteryRank.setVisible(false);
      this.masteryCaption.setVisible(false);
      this.masteryReward.setVisible(false);
      this.masteryMeter.setVisible(false);
      this.masteryMeterBounds = null;
    }

    const rewardVisible = this.content.rewardActionLabel !== null && this.actions.doubleCoins !== undefined;
    const buttonsY = y + height - buttonHeight - Math.max(gap, height * 0.06);
    if (rewardVisible) {
      const rewardWidth = innerWidth * 0.31;
      const standardWidth = (innerWidth - rewardWidth - gap * 2) / 2;
      this.layoutButton(this.secondary, { x: innerX, y: buttonsY, width: standardWidth, height: buttonHeight }, false);
      this.layoutButton(this.primary, { x: innerX + standardWidth + gap, y: buttonsY, width: standardWidth, height: buttonHeight }, true);
      this.layoutButton(this.rewardAction, {
        x: innerX + standardWidth * 2 + gap * 2,
        y: buttonsY,
        width: rewardWidth,
        height: buttonHeight,
      }, true);
    } else {
      const buttonWidth = (innerWidth - gap) / 2;
      this.layoutButton(this.secondary, { x: innerX, y: buttonsY, width: buttonWidth, height: buttonHeight }, false);
      this.layoutButton(this.primary, { x: innerX + buttonWidth + gap, y: buttonsY, width: buttonWidth, height: buttonHeight }, true);
      this.setButtonVisible(this.rewardAction, false);
    }
  }

  destroy(): void {
    this.dimmer.destroy();
    this.panel.destroy();
    this.kicker.destroy();
    this.title.destroy();
    this.result.destroy();
    this.rewardIcon.destroy();
    this.reward.destroy();
    this.detail.destroy();
    this.notice.destroy();
    this.masteryBadge.destroy();
    this.masteryRank.destroy();
    this.masteryCaption.destroy();
    this.masteryReward.destroy();
    this.masteryMeter.destroy();
    this.destroyButton(this.primary);
    this.destroyButton(this.secondary);
    this.destroyButton(this.rewardAction);
  }

  private syncContent(): void {
    this.kicker.setText(this.content.kicker ?? '').setVisible(Boolean(this.content.kicker));
    this.title.setText(this.content.title);
    this.result.setText(this.content.resultLine);
    this.reward.setText(this.content.rewardLine ?? '').setVisible(Boolean(this.content.rewardLine));
    this.rewardIcon.setVisible(Boolean(this.content.rewardLine) && this.content.rewardCoins !== null);
    this.detail.setText(this.content.detailLine ?? '').setVisible(Boolean(this.content.detailLine));
    this.notice.setText(this.content.noticeLine ?? '').setVisible(Boolean(this.content.noticeLine));
    this.primary.label.setText(this.content.primaryActionLabel);
    this.secondary.label.setText(this.content.secondaryActionLabel);
    this.rewardAction.label.setText(this.content.rewardActionLabel ?? '');
    this.rewardAction.enabled = this.content.rewardActionEnabled;
    const mastery = this.content.mastery;
    if (mastery) {
      this.masteryBadge.setTexture(CASCADE_UI_ART_KEYS.rank[mastery.afterRank]);
      this.masteryRank.setText(mastery.afterRankLabel);
      this.masteryCaption.setText(mastery.afterCaption);
      this.masteryReward.setText(mastery.rewardLine ?? '').setVisible(Boolean(mastery.rewardLine));
      this.masteryMeter.setProgress({ current: mastery.afterProgressCurrent, total: mastery.afterProgressTotal });
    }
    if (this.lastLayout) this.layout(this.lastLayout);
    if (!this.visible) this.setVisible(false);
  }

  private createButton(scene: Phaser.Scene, action: () => void, depth: number): OverlayButton {
    const surface = new UiSurface(scene, depth);
    const label = scene.add.text(0, 0, '', {
      color: '#24302e', fontFamily: 'system-ui, sans-serif', fontStyle: 'bold', align: 'center',
    }).setOrigin(0.5).setDepth(depth + 0.1);
    const zone = scene.add.zone(0, 0, 1, 1).setOrigin(0).setDepth(depth + 0.2).setInteractive();
    const button: OverlayButton = { surface, label, zone, action, enabled: true };
    zone.on('pointerdown', () => {
      if (button.enabled) {
        playUiButtonSound(scene);
        button.action();
      }
    });
    return button;
  }

  private layoutButton(
    button: OverlayButton,
    bounds: { readonly x: number; readonly y: number; readonly width: number; readonly height: number },
    primary: boolean,
  ): void {
    this.setButtonVisible(button, true);
    const alpha = button.enabled ? 1 : 0.45;
    button.surface.layout(bounds, primary ? 'gold' : 'paper');
    button.surface.feedback(button.enabled ? 'normal' : 'disabled');
    button.label.setAlpha(alpha)
      .setPosition(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2)
      .setFontSize(Math.max(11, Math.min(18, bounds.height * 0.34)));
    button.zone.setPosition(bounds.x, bounds.y).setSize(bounds.width, bounds.height);
    if (button.enabled) button.zone.setInteractive();
    else button.zone.disableInteractive();
  }

  private setButtonVisible(button: OverlayButton, visible: boolean): void {
    button.surface.setVisible(visible);
    button.label.setVisible(visible);
    button.zone.setVisible(visible).setActive(visible);
    if (!visible) button.zone.disableInteractive();
  }

  private destroyButton(button: OverlayButton): void {
    button.surface.destroy();
    button.label.destroy();
    button.zone.destroy();
  }
}
