import type { LayoutBounds, ViewportLayout } from '../../game/view/ViewportLayout.ts';

export interface GameHudLayout {
  readonly home: LayoutBounds;
  readonly newDeal: LayoutBounds;
  readonly restart: LayoutBounds;
  readonly undo: LayoutBounds;
  readonly hint: LayoutBounds;
  readonly settings: LayoutBounds;
  readonly metrics: LayoutBounds;
}

export function calculateGameHudLayout(layout: ViewportLayout, newDealVisible = true): GameHudLayout {
  const gap = Math.max(1, layout.newDealControl.y - (layout.homeControl.y + layout.homeControl.height));
  const restart: LayoutBounds = newDealVisible ? layout.undoControl : layout.newDealControl;
  const undo: LayoutBounds = {
    x: restart.x,
    y: restart.y + restart.height + gap,
    width: restart.width,
    height: restart.height,
  };
  const hint: LayoutBounds = {
    x: undo.x,
    y: undo.y + undo.height + gap,
    width: undo.width,
    height: undo.height,
  };
  const settings: LayoutBounds = {
    x: hint.x,
    y: hint.y + hint.height + gap,
    width: hint.width,
    height: hint.height,
  };
  const boardBottom = layout.boardBounds.y + layout.boardBounds.height;
  const metricsY = settings.y + settings.height + gap;
  return {
    home: layout.homeControl,
    newDeal: layout.newDealControl,
    restart,
    undo,
    hint,
    settings,
    metrics: {
      x: settings.x,
      y: metricsY,
      width: settings.width,
      height: Math.max(1, boardBottom - metricsY),
    },
  };
}
