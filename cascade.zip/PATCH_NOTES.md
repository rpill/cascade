# Card-back regression hotfix

Restores the approved rounded transparent card backs for Navy Study and Burgundy Club after the stale-base WebP migration regressed them.

- Navy Study runtime back: 432×604, alpha preserved, no runtime crop.
- Burgundy Club runtime back: 432×604, alpha preserved, no runtime crop.
- Both shop previews: 165×230 with transparency.
- Removes the stale Burgundy `crop` from ThemeRegistry.
- Updates theme manifests/README source-of-truth notes.
- Adds `tests/card-back-edge-regression.test.ts` to prevent recurrence.
