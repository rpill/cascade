import {
  appendFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  renameSync,
  writeFileSync,
} from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

import { createDealForMode } from '../../src/game/model/deal.ts';
import { solveSeed as defaultSolveSeed } from './solver-client.mjs';
import { verifyProofRecord as defaultVerifyProofRecord } from './verify-proof.mjs';

export const FAST_NODE_BUDGET = 250_000;
export const SLOW_NODE_BUDGET = 2_000_000;
export const STANDARD_SOURCE_START = 1;
export const DAILY_SOURCE_START = 1_000_000_001;
const MAX_UINT32 = 0xffff_ffff;

function assertPositiveUint32(value, label = 'seed') {
  if (!Number.isInteger(value) || value < 1 || value > MAX_UINT32) {
    throw new RangeError(`${label} must be a positive uint32, got ${String(value)}`);
  }
  return value;
}

function ensureParent(filePath) {
  mkdirSync(path.dirname(path.resolve(filePath)), { recursive: true });
}

function writeCheckpointAtomic(checkpointPath, checkpoint) {
  ensureParent(checkpointPath);
  const tempPath = `${checkpointPath}.tmp`;
  writeFileSync(tempPath, `${JSON.stringify(checkpoint, null, 2)}\n`, 'utf8');
  renameSync(tempPath, checkpointPath);
}

export function readCheckpoint(checkpointPath) {
  if (!existsSync(checkpointPath)) return null;
  const parsed = JSON.parse(readFileSync(checkpointPath, 'utf8'));
  if (parsed?.version !== 1) throw new Error(`Unsupported generation checkpoint version: ${String(parsed?.version)}`);
  return parsed;
}

export function appendCandidate(outputPath, record) {
  ensureParent(outputPath);
  appendFileSync(outputPath, `${JSON.stringify(record)}\n`, 'utf8');
}

function readOutputSeeds(outputPath) {
  if (!existsSync(outputPath)) return new Set();
  const text = readFileSync(outputPath, 'utf8').trim();
  if (!text) return new Set();
  return new Set(text.split('\n').map((line) => JSON.parse(line).seed));
}

function freshCheckpoint(startSeed, maxSeeds) {
  return {
    version: 1,
    startSeed,
    maxSeeds,
    nextSeed: startSeed,
    scannedCount: 0,
    acceptedCount: 0,
    rejectedVerificationCount: 0,
    unsolvableCount: 0,
    undeterminedCount: 0,
    unresolvedRetryQueue: [],
  };
}

function validateResume(checkpoint, startSeed, maxSeeds) {
  if (checkpoint.startSeed !== startSeed || checkpoint.maxSeeds !== maxSeeds) {
    throw new Error(
      `Checkpoint range mismatch: checkpoint start=${checkpoint.startSeed} max=${checkpoint.maxSeeds}; requested start=${startSeed} max=${maxSeeds}`,
    );
  }
}

async function solveFinalRecord(seed, checkpoint, options) {
  const { solveSeed, fastBudget, slowBudget, checkpointPath } = options;
  let result;
  let usedBudget;
  const queued = checkpoint.unresolvedRetryQueue.includes(seed);

  if (queued) {
    usedBudget = slowBudget;
    result = await solveSeed({ seed, budget: usedBudget, solverPath: options.solverPath });
  } else {
    usedBudget = fastBudget;
    result = await solveSeed({ seed, budget: usedBudget, solverPath: options.solverPath });
    if (result.status === 'UNDETERMINED') {
      checkpoint.unresolvedRetryQueue.push(seed);
      writeCheckpointAtomic(checkpointPath, checkpoint);
      usedBudget = slowBudget;
      result = await solveSeed({ seed, budget: usedBudget, solverPath: options.solverPath });
    }
  }

  checkpoint.unresolvedRetryQueue = checkpoint.unresolvedRetryQueue.filter((queuedSeed) => queuedSeed !== seed);
  return { ...result, budget: usedBudget };
}

export async function scanRange({
  startSeed,
  maxSeeds,
  checkpointPath,
  outputPath,
  stopAfter = Number.POSITIVE_INFINITY,
  batchSize = 32,
  solveSeed = defaultSolveSeed,
  verifyProofRecord = defaultVerifyProofRecord,
  fastBudget = FAST_NODE_BUDGET,
  slowBudget = SLOW_NODE_BUDGET,
  solverPath,
} = {}) {
  assertPositiveUint32(startSeed, 'startSeed');
  if (!Number.isSafeInteger(maxSeeds) || maxSeeds < 1) throw new RangeError(`maxSeeds must be >= 1, got ${String(maxSeeds)}`);
  const endSeed = startSeed + maxSeeds - 1;
  assertPositiveUint32(endSeed, 'endSeed');
  if (!checkpointPath || !outputPath) throw new Error('checkpointPath and outputPath are required');
  if (!Number.isSafeInteger(batchSize) || batchSize < 1) throw new RangeError(`batchSize must be >= 1, got ${String(batchSize)}`);

  let checkpoint = readCheckpoint(checkpointPath) ?? freshCheckpoint(startSeed, maxSeeds);
  validateResume(checkpoint, startSeed, maxSeeds);
  const outputSeeds = readOutputSeeds(outputPath);

  // Recover from a crash after JSONL append but before checkpoint replacement.
  while (checkpoint.nextSeed <= endSeed && outputSeeds.has(checkpoint.nextSeed)) {
    checkpoint.nextSeed += 1;
    checkpoint.scannedCount += 1;
  }

  let completedThisRun = 0;
  let sinceCheckpoint = 0;

  while (checkpoint.nextSeed <= endSeed && completedThisRun < stopAfter) {
    const seed = checkpoint.unresolvedRetryQueue[0] ?? checkpoint.nextSeed;
    assertPositiveUint32(seed);

    const solved = await solveFinalRecord(seed, checkpoint, {
      solveSeed,
      fastBudget,
      slowBudget,
      checkpointPath,
      solverPath,
    });

    let verification = null;
    if (solved.status === 'SOLVED') {
      verification = await verifyProofRecord(solved);
      if (verification.ok) checkpoint.acceptedCount += 1;
      else checkpoint.rejectedVerificationCount += 1;
    } else if (solved.status === 'UNSOLVABLE') {
      checkpoint.unsolvableCount += 1;
    } else {
      checkpoint.undeterminedCount += 1;
    }

    const record = {
      seed,
      status: solved.status,
      nodes: solved.nodes,
      budget: solved.budget,
      ...(solved.status === 'SOLVED' ? { initialStockCount: createDealForMode('winnable', BigInt(seed)).stock.length } : {}),
      ...(solved.proof ? { proof: solved.proof } : {}),
      ...(verification ? { verification } : {}),
    };

    if (!outputSeeds.has(seed)) {
      appendCandidate(outputPath, record);
      outputSeeds.add(seed);
    }

    checkpoint.scannedCount += 1;
    checkpoint.nextSeed = Math.max(checkpoint.nextSeed, seed + 1);
    completedThisRun += 1;
    sinceCheckpoint += 1;

    if (sinceCheckpoint >= batchSize) {
      writeCheckpointAtomic(checkpointPath, checkpoint);
      sinceCheckpoint = 0;
    }
  }

  writeCheckpointAtomic(checkpointPath, checkpoint);
  return checkpoint;
}

function parseCliArgs(argv) {
  const options = {};
  for (let index = 0; index < argv.length; index += 2) {
    const key = argv[index];
    const value = argv[index + 1];
    if (!key?.startsWith('--') || value === undefined) throw new Error(`Invalid argument near ${String(key)}`);
    options[key.slice(2)] = value;
  }
  const source = options.source ?? 'standard';
  const startSeed = options.start ? Number(options.start) : source === 'daily' ? DAILY_SOURCE_START : STANDARD_SOURCE_START;
  const maxSeeds = Number(options.count ?? 1000);
  const root = path.resolve('artifacts', 'deals', source);
  return {
    startSeed,
    maxSeeds,
    checkpointPath: options.checkpoint ?? path.join(root, 'checkpoint.json'),
    outputPath: options.out ?? path.join(root, 'candidates.jsonl'),
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  scanRange(parseCliArgs(process.argv.slice(2)))
    .then((checkpoint) => process.stdout.write(`${JSON.stringify(checkpoint, null, 2)}\n`))
    .catch((error) => {
      console.error(error instanceof Error ? error.stack : String(error));
      process.exitCode = 1;
    });
}
